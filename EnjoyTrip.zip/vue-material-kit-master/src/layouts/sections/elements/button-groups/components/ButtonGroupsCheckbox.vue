<script setup></script>
<template>
  <section class="py-7 m-3 bg-gray-100">
    <div class="container">
      <div class="row justify-space-between text-center py-2">
        <div class="col-6 mx-auto">
          <div
            class="btn-group"
            role="group"
            aria-label="Basic checkbox toggle button group"
          >
            <input
              type="checkbox"
              class="btn-check"
              id="btncheck1"
              autocomplete="off"
            />
            <label class="btn btn-outline-dark" for="btncheck1"
              >Checkbox 1</label
            >

            <input
              type="checkbox"
              class="btn-check"
              id="btncheck2"
              autocomplete="off"
            />
            <label class="btn btn-outline-dark" for="btncheck2"
              >Checkbox 2</label
            >

            <input
              type="checkbox"
              class="btn-check"
              id="btncheck3"
              autocomplete="off"
            />
            <label class="btn btn-outline-dark" for="btncheck3"
              >Checkbox 3</label
            >
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
